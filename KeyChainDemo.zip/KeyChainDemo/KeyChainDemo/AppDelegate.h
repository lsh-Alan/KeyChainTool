//
//  AppDelegate.h
//  KeyChainDemo
//
//  Created by Alan on 2019/2/22.
//  Copyright © 2019 Alan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

